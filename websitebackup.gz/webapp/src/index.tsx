import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// API endpoint for contact form
app.post('/api/contact', async (c) => {
  try {
    const { name, email, phone, company, service, message } = await c.req.json()
    
    // Validate required fields
    if (!name || !email || !message) {
      return c.json({ success: false, error: 'Required fields missing' }, 400)
    }
    
    // In production, you would send this to your CRM, email service, etc.
    console.log('Contact form submission:', { name, email, phone, company, service, message })
    
    return c.json({ 
      success: true, 
      message: 'Thank you for reaching out! We\'ll get back to you within 24 hours.' 
    })
  } catch (error) {
    return c.json({ success: false, error: 'Failed to process request' }, 500)
  }
})

// Main homepage
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BrightPulse Media - Digital Marketing That Drives Results</title>
        <meta name="description" content="Transform your digital presence with BrightPulse Media. Expert SEO, social media marketing, and ad campaigns that deliver real results for small businesses.">
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/style.css" rel="stylesheet">
        <script>
          tailwind.config = {
            theme: {
              extend: {
                colors: {
                  primary: '#FF6B35',
                  secondary: '#F7931E',
                  dark: '#1A1A2E',
                  light: '#F5F5F5'
                }
              }
            }
          }
        </script>
    </head>
    <body class="bg-white text-gray-800">
        <!-- Navigation -->
        <nav class="fixed w-full bg-white shadow-md z-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-20">
                    <div class="flex items-center">
                        <div class="flex items-center">
                            <div class="bg-gradient-to-r from-primary to-secondary rounded-lg p-2">
                                <i class="fas fa-bolt text-white text-2xl"></i>
                            </div>
                            <span class="ml-3 text-2xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                                BrightPulse Media
                            </span>
                        </div>
                    </div>
                    <div class="hidden md:flex space-x-8">
                        <a href="#services" class="text-gray-700 hover:text-primary transition">Services</a>
                        <a href="#results" class="text-gray-700 hover:text-primary transition">Results</a>
                        <a href="#testimonials" class="text-gray-700 hover:text-primary transition">Testimonials</a>
                        <a href="#contact" class="bg-gradient-to-r from-primary to-secondary text-white px-6 py-2 rounded-full hover:shadow-lg transition">
                            Get Started
                        </a>
                    </div>
                    <div class="md:hidden">
                        <button id="mobileMenuBtn" class="text-gray-700">
                            <i class="fas fa-bars text-2xl"></i>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Mobile Menu -->
            <div id="mobileMenu" class="hidden md:hidden bg-white border-t">
                <div class="px-4 py-4 space-y-3">
                    <a href="#services" class="block text-gray-700 hover:text-primary">Services</a>
                    <a href="#results" class="block text-gray-700 hover:text-primary">Results</a>
                    <a href="#testimonials" class="block text-gray-700 hover:text-primary">Testimonials</a>
                    <a href="#contact" class="block bg-gradient-to-r from-primary to-secondary text-white px-6 py-2 rounded-full text-center">
                        Get Started
                    </a>
                </div>
            </div>
        </nav>

        <!-- Hero Section -->
        <section class="pt-32 pb-20 bg-gradient-to-br from-primary/10 via-secondary/5 to-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid md:grid-cols-2 gap-12 items-center">
                    <div>
                        <div class="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
                            <i class="fas fa-star mr-2"></i>
                            Trusted by 200+ Growing Businesses
                        </div>
                        <h1 class="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                            Your Brand's 
                            <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                                Digital Breakthrough
                            </span>
                            Starts Here
                        </h1>
                        <p class="text-xl text-gray-600 mb-8 leading-relaxed">
                            Stop getting lost in the noise. We turn small businesses into industry leaders with 
                            data-driven SEO, scroll-stopping social media, and ad campaigns that actually convert.
                        </p>
                        <div class="flex flex-col sm:flex-row gap-4">
                            <a href="#contact" class="bg-gradient-to-r from-primary to-secondary text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-xl transition inline-flex items-center justify-center">
                                Grow Your Business
                                <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                            <a href="#results" class="border-2 border-primary text-primary px-8 py-4 rounded-full text-lg font-semibold hover:bg-primary hover:text-white transition inline-flex items-center justify-center">
                                See Our Results
                                <i class="fas fa-chart-line ml-2"></i>
                            </a>
                        </div>
                        <div class="mt-8 flex items-center gap-8 text-sm text-gray-500">
                            <div class="flex items-center">
                                <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                No Long-term Contracts
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                ROI-Focused Approach
                            </div>
                        </div>
                    </div>
                    <div class="relative">
                        <div class="bg-gradient-to-br from-primary to-secondary rounded-3xl p-8 text-white shadow-2xl transform hover:scale-105 transition">
                            <div class="mb-6">
                                <i class="fas fa-rocket text-6xl opacity-20"></i>
                            </div>
                            <h3 class="text-2xl font-bold mb-4">Average Client Results</h3>
                            <div class="space-y-4">
                                <div class="flex items-center justify-between">
                                    <span>Traffic Increase</span>
                                    <span class="text-3xl font-bold">247%</span>
                                </div>
                                <div class="bg-white/20 h-2 rounded-full">
                                    <div class="bg-white h-2 rounded-full w-[95%]"></div>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span>Lead Generation</span>
                                    <span class="text-3xl font-bold">3.5x</span>
                                </div>
                                <div class="bg-white/20 h-2 rounded-full">
                                    <div class="bg-white h-2 rounded-full w-[85%]"></div>
                                </div>
                                <div class="flex items-center justify-between">
                                    <span>Social Engagement</span>
                                    <span class="text-3xl font-bold">412%</span>
                                </div>
                                <div class="bg-white/20 h-2 rounded-full">
                                    <div class="bg-white h-2 rounded-full w-[90%]"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Trust Indicators -->
        <section class="py-12 bg-dark text-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                    <div>
                        <div class="text-4xl font-bold text-secondary mb-2">200+</div>
                        <div class="text-gray-400">Happy Clients</div>
                    </div>
                    <div>
                        <div class="text-4xl font-bold text-secondary mb-2">$12M+</div>
                        <div class="text-gray-400">Revenue Generated</div>
                    </div>
                    <div>
                        <div class="text-4xl font-bold text-secondary mb-2">98%</div>
                        <div class="text-gray-400">Client Retention</div>
                    </div>
                    <div>
                        <div class="text-4xl font-bold text-secondary mb-2">5 Years</div>
                        <div class="text-gray-400">Industry Experience</div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section -->
        <section id="services" class="py-20 bg-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold mb-4">
                        Services That 
                        <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                            Actually Work
                        </span>
                    </h2>
                    <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                        No fluff, no empty promises. Just proven strategies that get you found, 
                        build your brand, and drive real business growth.
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-8">
                    <!-- SEO Service -->
                    <div class="bg-gradient-to-br from-white to-primary/5 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition border border-primary/10">
                        <div class="bg-gradient-to-br from-primary to-secondary rounded-xl w-16 h-16 flex items-center justify-center mb-6">
                            <i class="fas fa-search text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">Search Engine Optimization</h3>
                        <p class="text-gray-600 mb-6">
                            Stop hiding on page 10. We'll get your business on Google's first page where 
                            your customers are actually looking.
                        </p>
                        <ul class="space-y-3 mb-6">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Local & National SEO strategies</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Keyword research & optimization</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Technical SEO & site audits</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Content optimization & link building</span>
                            </li>
                        </ul>
                        <div class="bg-primary/10 rounded-lg p-4">
                            <div class="text-sm text-gray-600 mb-1">Average Result</div>
                            <div class="text-2xl font-bold text-primary">247% Traffic Boost</div>
                        </div>
                    </div>

                    <!-- Social Media Marketing -->
                    <div class="bg-gradient-to-br from-white to-secondary/5 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition border border-secondary/10">
                        <div class="bg-gradient-to-br from-primary to-secondary rounded-xl w-16 h-16 flex items-center justify-center mb-6">
                            <i class="fas fa-hashtag text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">Social Media Marketing</h3>
                        <p class="text-gray-600 mb-6">
                            Turn scrollers into customers. We create content that stops thumbs, 
                            builds communities, and drives sales.
                        </p>
                        <ul class="space-y-3 mb-6">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Strategic content planning</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Platform management (FB, IG, LinkedIn)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Community engagement & growth</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Analytics & performance tracking</span>
                            </li>
                        </ul>
                        <div class="bg-secondary/10 rounded-lg p-4">
                            <div class="text-sm text-gray-600 mb-1">Average Result</div>
                            <div class="text-2xl font-bold text-secondary">412% Engagement Up</div>
                        </div>
                    </div>

                    <!-- Ad Campaigns -->
                    <div class="bg-gradient-to-br from-white to-primary/5 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition border border-primary/10">
                        <div class="bg-gradient-to-br from-primary to-secondary rounded-xl w-16 h-16 flex items-center justify-center mb-6">
                            <i class="fas fa-bullhorn text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">Paid Ad Campaigns</h3>
                        <p class="text-gray-600 mb-6">
                            Every dollar counts. We create laser-focused ad campaigns that maximize 
                            your ROI and turn clicks into customers.
                        </p>
                        <ul class="space-y-3 mb-6">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Google Ads & PPC management</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Facebook & Instagram ads</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>A/B testing & optimization</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                <span>Landing page optimization</span>
                            </li>
                        </ul>
                        <div class="bg-primary/10 rounded-lg p-4">
                            <div class="text-sm text-gray-600 mb-1">Average Result</div>
                            <div class="text-2xl font-bold text-primary">3.5x Lead Generation</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Results Section -->
        <section id="results" class="py-20 bg-gradient-to-br from-dark to-gray-900 text-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold mb-4">
                        Real Businesses. Real Results.
                    </h2>
                    <p class="text-xl text-gray-300 max-w-3xl mx-auto">
                        We don't just promise growth—we deliver it. Here's what happens when small 
                        businesses partner with BrightPulse Media.
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-8">
                    <div class="bg-white/5 backdrop-blur rounded-2xl p-8 border border-white/10">
                        <div class="text-secondary text-5xl font-bold mb-2">185%</div>
                        <div class="text-xl font-semibold mb-3">Revenue Growth</div>
                        <p class="text-gray-400 mb-4">
                            Local plumbing company saw 185% revenue increase in 8 months through 
                            targeted local SEO and Google Ads.
                        </p>
                        <div class="flex items-center text-sm text-gray-500">
                            <i class="fas fa-building mr-2"></i>
                            Home Services
                        </div>
                    </div>

                    <div class="bg-white/5 backdrop-blur rounded-2xl p-8 border border-white/10">
                        <div class="text-secondary text-5xl font-bold mb-2">12K</div>
                        <div class="text-xl font-semibold mb-3">Followers in 6 Months</div>
                        <p class="text-gray-400 mb-4">
                            Fashion boutique grew from 800 to 12,000 Instagram followers with 
                            strategic content and influencer partnerships.
                        </p>
                        <div class="flex items-center text-sm text-gray-500">
                            <i class="fas fa-shopping-bag mr-2"></i>
                            Retail & E-commerce
                        </div>
                    </div>

                    <div class="bg-white/5 backdrop-blur rounded-2xl p-8 border border-white/10">
                        <div class="text-secondary text-5xl font-bold mb-2">450%</div>
                        <div class="text-xl font-semibold mb-3">More Qualified Leads</div>
                        <p class="text-gray-400 mb-4">
                            B2B software company increased demo bookings by 450% through 
                            LinkedIn ads and content marketing.
                        </p>
                        <div class="flex items-center text-sm text-gray-500">
                            <i class="fas fa-laptop-code mr-2"></i>
                            Technology & SaaS
                        </div>
                    </div>
                </div>

                <div class="mt-16 text-center">
                    <a href="#contact" class="inline-flex items-center bg-gradient-to-r from-primary to-secondary text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-xl transition">
                        Get Similar Results
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </section>

        <!-- Testimonials Section -->
        <section id="testimonials" class="py-20 bg-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold mb-4">
                        What Our 
                        <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                            Clients Say
                        </span>
                    </h2>
                    <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                        Don't take our word for it. Hear from business owners who transformed 
                        their digital presence with BrightPulse Media.
                    </p>
                </div>

                <div class="grid md:grid-cols-3 gap-8">
                    <!-- Testimonial 1 -->
                    <div class="bg-gradient-to-br from-white to-primary/5 rounded-2xl p-8 shadow-lg border border-primary/10">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                        </div>
                        <p class="text-gray-700 mb-6 italic">
                            "BrightPulse Media completely transformed our online presence. We went from 
                            barely being found on Google to ranking #1 for our main keywords. Our phone 
                            is ringing off the hook now!"
                        </p>
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-xl">
                                S
                            </div>
                            <div class="ml-4">
                                <div class="font-bold">Sarah Mitchell</div>
                                <div class="text-sm text-gray-500">Owner, Mitchell's HVAC</div>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 2 -->
                    <div class="bg-gradient-to-br from-white to-secondary/5 rounded-2xl p-8 shadow-lg border border-secondary/10">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                        </div>
                        <p class="text-gray-700 mb-6 italic">
                            "Their social media strategies are incredible. We tripled our Instagram 
                            following and actually see real customers coming through those channels now. 
                            Best investment we've made!"
                        </p>
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-xl">
                                M
                            </div>
                            <div class="ml-4">
                                <div class="font-bold">Marcus Thompson</div>
                                <div class="text-sm text-gray-500">CEO, Urban Threads Boutique</div>
                            </div>
                        </div>
                    </div>

                    <!-- Testimonial 3 -->
                    <div class="bg-gradient-to-br from-white to-primary/5 rounded-2xl p-8 shadow-lg border border-primary/10">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                            <i class="fas fa-star text-secondary"></i>
                        </div>
                        <p class="text-gray-700 mb-6 italic">
                            "Finally, a marketing agency that understands ROI. Every dollar we spend with 
                            BrightPulse comes back multiplied. They're true partners in our growth."
                        </p>
                        <div class="flex items-center">
                            <div class="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center text-white font-bold text-xl">
                                J
                            </div>
                            <div class="ml-4">
                                <div class="font-bold">Jennifer Park</div>
                                <div class="text-sm text-gray-500">Founder, TechFlow Solutions</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-16 bg-gradient-to-r from-primary to-secondary rounded-2xl p-12 text-white text-center">
                    <h3 class="text-3xl font-bold mb-4">Ready to Join Our Success Stories?</h3>
                    <p class="text-xl mb-8 opacity-90">
                        Your competitors are already investing in digital marketing. Don't get left behind.
                    </p>
                    <a href="#contact" class="inline-flex items-center bg-white text-primary px-8 py-4 rounded-full text-lg font-semibold hover:shadow-xl transition">
                        Let's Grow Together
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </section>

        <!-- Contact Form Section -->
        <section id="contact" class="py-20 bg-gradient-to-br from-light to-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid md:grid-cols-2 gap-12 items-start">
                    <div>
                        <h2 class="text-4xl md:text-5xl font-bold mb-6">
                            Let's Build Your
                            <span class="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
                                Digital Empire
                            </span>
                        </h2>
                        <p class="text-xl text-gray-600 mb-8">
                            Book a free 30-minute strategy session. We'll analyze your current digital 
                            presence and show you exactly how we can help you grow.
                        </p>

                        <div class="space-y-6 mb-8">
                            <div class="flex items-start">
                                <div class="bg-gradient-to-br from-primary to-secondary rounded-lg p-3 mr-4">
                                    <i class="fas fa-phone text-white"></i>
                                </div>
                                <div>
                                    <div class="font-semibold mb-1">Call Us</div>
                                    <div class="text-gray-600">(555) 123-4567</div>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <div class="bg-gradient-to-br from-primary to-secondary rounded-lg p-3 mr-4">
                                    <i class="fas fa-envelope text-white"></i>
                                </div>
                                <div>
                                    <div class="font-semibold mb-1">Email Us</div>
                                    <div class="text-gray-600">hello@brightpulsemedia.com</div>
                                </div>
                            </div>
                            <div class="flex items-start">
                                <div class="bg-gradient-to-br from-primary to-secondary rounded-lg p-3 mr-4">
                                    <i class="fas fa-clock text-white"></i>
                                </div>
                                <div>
                                    <div class="font-semibold mb-1">Business Hours</div>
                                    <div class="text-gray-600">Mon-Fri: 9AM - 6PM EST</div>
                                </div>
                            </div>
                        </div>

                        <div class="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-6">
                            <h4 class="font-bold mb-3">What Happens Next?</h4>
                            <ol class="space-y-2 text-gray-700">
                                <li class="flex items-start">
                                    <span class="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 text-sm">1</span>
                                    <span>We'll review your submission within 24 hours</span>
                                </li>
                                <li class="flex items-start">
                                    <span class="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 text-sm">2</span>
                                    <span>Schedule your free strategy session</span>
                                </li>
                                <li class="flex items-start">
                                    <span class="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center mr-3 flex-shrink-0 text-sm">3</span>
                                    <span>Get a custom growth plan for your business</span>
                                </li>
                            </ol>
                        </div>
                    </div>

                    <div class="bg-white rounded-2xl p-8 shadow-2xl">
                        <h3 class="text-2xl font-bold mb-6">Get Your Free Strategy Session</h3>
                        <form id="contactForm" class="space-y-4">
                            <div>
                                <label class="block text-sm font-semibold mb-2">Your Name *</label>
                                <input type="text" name="name" required 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                                       placeholder="John Smith">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-2">Email Address *</label>
                                <input type="email" name="email" required 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                                       placeholder="john@company.com">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-2">Phone Number</label>
                                <input type="tel" name="phone" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                                       placeholder="(555) 123-4567">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-2">Company Name</label>
                                <input type="text" name="company" 
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                                       placeholder="Your Business Name">
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-2">Service Interested In *</label>
                                <select name="service" required 
                                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary">
                                    <option value="">Select a service...</option>
                                    <option value="seo">SEO (Search Engine Optimization)</option>
                                    <option value="social">Social Media Marketing</option>
                                    <option value="ads">Paid Ad Campaigns</option>
                                    <option value="all">Complete Digital Marketing</option>
                                    <option value="other">Not Sure / Other</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm font-semibold mb-2">Tell Us About Your Goals *</label>
                                <textarea name="message" required rows="4" 
                                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary"
                                          placeholder="What are your biggest marketing challenges? What results are you looking for?"></textarea>
                            </div>
                            <button type="submit" 
                                    class="w-full bg-gradient-to-r from-primary to-secondary text-white px-8 py-4 rounded-lg text-lg font-semibold hover:shadow-xl transition">
                                Get My Free Strategy Session
                                <i class="fas fa-paper-plane ml-2"></i>
                            </button>
                            <p class="text-xs text-gray-500 text-center">
                                By submitting, you agree to receive marketing communications from BrightPulse Media. 
                                We respect your privacy and you can unsubscribe at any time.
                            </p>
                        </form>
                        <div id="formMessage" class="mt-4 hidden"></div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="bg-dark text-white py-12">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid md:grid-cols-4 gap-8 mb-8">
                    <div>
                        <div class="flex items-center mb-4">
                            <div class="bg-gradient-to-r from-primary to-secondary rounded-lg p-2">
                                <i class="fas fa-bolt text-white text-xl"></i>
                            </div>
                            <span class="ml-3 text-xl font-bold">BrightPulse Media</span>
                        </div>
                        <p class="text-gray-400 text-sm">
                            Empowering small businesses with digital marketing that delivers real results.
                        </p>
                    </div>
                    <div>
                        <h4 class="font-bold mb-4">Services</h4>
                        <ul class="space-y-2 text-gray-400 text-sm">
                            <li><a href="#services" class="hover:text-primary transition">SEO</a></li>
                            <li><a href="#services" class="hover:text-primary transition">Social Media Marketing</a></li>
                            <li><a href="#services" class="hover:text-primary transition">Paid Ad Campaigns</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-bold mb-4">Company</h4>
                        <ul class="space-y-2 text-gray-400 text-sm">
                            <li><a href="#results" class="hover:text-primary transition">Case Studies</a></li>
                            <li><a href="#testimonials" class="hover:text-primary transition">Testimonials</a></li>
                            <li><a href="#contact" class="hover:text-primary transition">Contact</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-bold mb-4">Connect With Us</h4>
                        <div class="flex space-x-4">
                            <a href="#" class="bg-white/10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary transition">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="bg-white/10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary transition">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a href="#" class="bg-white/10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary transition">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                            <a href="#" class="bg-white/10 w-10 h-10 rounded-full flex items-center justify-center hover:bg-primary transition">
                                <i class="fab fa-twitter"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="border-t border-white/10 pt-8 text-center text-gray-400 text-sm">
                    <p>&copy; 2024 BrightPulse Media. All rights reserved. Built with energy, creativity, and results in mind.</p>
                </div>
            </div>
        </footer>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

export default app
