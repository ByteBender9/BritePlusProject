// Mobile menu toggle
document.getElementById('mobileMenuBtn').addEventListener('click', () => {
  const mobileMenu = document.getElementById('mobileMenu');
  mobileMenu.classList.toggle('hidden');
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
      // Close mobile menu if open
      document.getElementById('mobileMenu').classList.add('hidden');
    }
  });
});

// Contact form submission
document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const formMessage = document.getElementById('formMessage');
  const submitButton = e.target.querySelector('button[type="submit"]');
  const originalButtonText = submitButton.innerHTML;
  
  // Disable button and show loading state
  submitButton.disabled = true;
  submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
  
  // Get form data
  const formData = new FormData(e.target);
  const data = {
    name: formData.get('name'),
    email: formData.get('email'),
    phone: formData.get('phone'),
    company: formData.get('company'),
    service: formData.get('service'),
    message: formData.get('message')
  };
  
  try {
    const response = await axios.post('/api/contact', data);
    
    if (response.data.success) {
      formMessage.className = 'mt-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-lg';
      formMessage.innerHTML = `
        <div class="flex items-center">
          <i class="fas fa-check-circle mr-2"></i>
          <span>${response.data.message}</span>
        </div>
      `;
      formMessage.classList.remove('hidden');
      
      // Reset form
      e.target.reset();
      
      // Hide message after 5 seconds
      setTimeout(() => {
        formMessage.classList.add('hidden');
      }, 5000);
    }
  } catch (error) {
    formMessage.className = 'mt-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg';
    formMessage.innerHTML = `
      <div class="flex items-center">
        <i class="fas fa-exclamation-circle mr-2"></i>
        <span>Oops! Something went wrong. Please try again or contact us directly at hello@brightpulsemedia.com</span>
      </div>
    `;
    formMessage.classList.remove('hidden');
  } finally {
    // Re-enable button
    submitButton.disabled = false;
    submitButton.innerHTML = originalButtonText;
  }
});

// Add scroll effect to navigation
window.addEventListener('scroll', () => {
  const nav = document.querySelector('nav');
  if (window.scrollY > 50) {
    nav.classList.add('shadow-lg');
  } else {
    nav.classList.remove('shadow-lg');
  }
});

// Animate stats on scroll (intersection observer)
const observerOptions = {
  threshold: 0.5,
  rootMargin: '0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('animate-fade-in');
    }
  });
}, observerOptions);

// Observe all service cards and testimonials
document.querySelectorAll('.grid > div').forEach(el => {
  observer.observe(el);
});
